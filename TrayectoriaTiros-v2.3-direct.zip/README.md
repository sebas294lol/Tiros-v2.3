# Trayectoria de Tiros v2.3

Simulador independiente de tiros de fútbol, optimizado para teléfonos modestos.

Incluye Normal, Retos, Modo Portero, Tiros Libres y Penales; potencia, curva, altura, objetivo, dificultad, portero manual y salto al punto tocado.

La animación usa una trayectoria precalculada en memoria y evita crear objetos durante cada frame.
