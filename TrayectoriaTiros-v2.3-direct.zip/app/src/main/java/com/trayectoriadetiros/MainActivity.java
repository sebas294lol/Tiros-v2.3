package com.trayectoriadetiros;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.Random;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(4,16,9));
        getWindow().setNavigationBarColor(Color.rgb(4,16,9));
        game = new GameView(this);
        setContentView(game);
    }
    @Override public void onBackPressed() {
        if (game.screen != 0) { game.screen = 0; game.reset(); game.invalidate(); }
        else super.onBackPressed();
    }
}

class GameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path trailPath = new Path();
    private final Random rng = new Random();
    private Bitmap playerBmp, keeperBmp, pitchBmp, netBmp;

    int screen = 0; // 0 menu, 1 normal, 2 retos, 3 portero, 4 libres, 5 penales
    int difficulty = 1;
    int W, H;
    float power = 70f, curve = 0f, height = 55f;
    float startX, startY, targetX, targetY, ballX, ballY;
    float keeperX, keeperY, keeperGoalX, keeperGoalY;
    float[] pathX = new float[121], pathY = new float[121];
    int pathCount = 0, pathIndex = 0;
    long lastFrameNs = 0L;
    float shotTime = 0f, shotDuration = 1f;
    float playerAnim = 0f, keeperAnim = 0f;
    boolean shooting = false, keeperDiving = false, draggingKeeper = false;
    boolean shotResolved = false;
    int attempts = 0, goals = 0, saves = 0, streak = 0, record = 0, challenge = 0;
    String toast = "";
    long toastUntil = 0L;

    GameView(Context c) {
        super(c);
        setFocusable(true);
        p.setTypeface(Typeface.create("sans", Typeface.BOLD));
        playerBmp = load(c, "player_sprite");
        keeperBmp = load(c, "keeper_sprite");
        pitchBmp = load(c, "pitch_texture");
        netBmp = load(c, "net_texture");
    }

    Bitmap load(Context c, String name) {
        int id = c.getResources().getIdentifier(name, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(c.getResources(), id);
    }

    void reset() {
        shooting = false; keeperDiving = false; draggingKeeper = false; shotResolved = false;
        pathCount = 0; pathIndex = 0; shotTime = 0f; playerAnim = 0f; keeperAnim = 0f;
        startX = startY = targetX = targetY = ballX = ballY = 0f;
        keeperX = keeperY = keeperGoalX = keeperGoalY = 0f;
        trailPath.reset();
        challenge = 0;
        if (W > 0 && H > 0) chooseDefault();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        W = getWidth(); H = getHeight();
        if (screen == 0) drawMenu(c); else drawGame(c);
        long now = System.currentTimeMillis();
        if (toastUntil > now) {
            round(c, 18, H - 68, W - 18, H - 18, 18, 0xe9111111);
            text(c, toast, W / 2f, H - 38, 15, Color.WHITE, Paint.Align.CENTER);
        }
        if (shooting) {
            updateFrame();
            postInvalidateOnAnimation();
        } else if (toastUntil > now) {
            postInvalidateDelayed(40);
        }
    }

    void drawMenu(Canvas c) {
        c.drawColor(Color.rgb(5,18,10));
        text(c, "⚽ TRAYECTORIA DE TIROS", W/2f, 70, 25, Color.WHITE, Paint.Align.CENTER);
        text(c, "v2.3 • simulador ligero", W/2f, 98, 14, 0xffa8d8b4, Paint.Align.CENTER);
        String[] names = {"🎯  NORMAL", "🏆  RETOS", "🧤  MODO PORTERO", "⚽  TIROS LIBRES", "🥅  PENALES"};
        int[] cols = {0xff176b37,0xff145d83,0xff70451b,0xff5a3a77,0xff75402e};
        float top = Math.max(145f, H * .22f);
        float bottom = Math.min(H - 90f, top + 310f);
        float gap = (bottom - top) / 4f;
        for (int i=0;i<5;i++) button(c, names[i], top+i*gap, cols[i]);
        text(c, "Récord de racha: " + record, W/2f, H-30, 12, 0xff8aa391, Paint.Align.CENTER);
    }

    void drawGame(Canvas c) {
        drawPitch(c);
        drawHeader(c);
        drawScene(c);
        drawControls(c);
    }

    void drawPitch(Canvas c) {
        p.setStyle(Paint.Style.FILL); p.setColor(0xff176f3b); c.drawRect(0,0,W,H,p);
        if (pitchBmp != null) { p.setAlpha(35); c.drawBitmap(pitchBmp,null,new Rect(0,0,W,H),p); p.setAlpha(255); }
        p.setColor(0x22000000);
        for (int i=0;i<10;i+=2) c.drawRect(i*W/10f,0,(i+1)*W/10f,H,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(0xffe4f5e6);
        c.drawRect(16,32,W-16,H-16,p); c.drawLine(W/2f,32,W/2f,H-16,p); c.drawCircle(W/2f,H*.54f,54,p);
        float gx=goalX(), gy=goalY(), gw=goalW(), gh=goalH();
        p.setStrokeWidth(5); c.drawRect(gx,gy,gx+gw,gy+gh,p);
        p.setStrokeWidth(2); c.drawRect(gx-30,gy+45,gx+gw+30,gy+gh-45,p);
        if (netBmp != null) { p.setAlpha(70); c.drawBitmap(netBmp,null,new RectF(gx,gy,gx+gw,gy+gh),p); p.setAlpha(255); }
        if (!shooting && screen != 3 && targetX > 0) {
            p.setStyle(Paint.Style.FILL); p.setColor(0x66ffffff); c.drawCircle(targetX,targetY,17,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.WHITE); c.drawCircle(targetX,targetY,17,p);
        }
    }

    void drawHeader(Canvas c) {
        round(c,10,8,W-10,58,16,0xcc092012);
        text(c, modeName(), 22, 40, 18, Color.WHITE, Paint.Align.LEFT);
        text(c, "G " + goals + "  •  T " + attempts + "  •  R " + streak, W-22, 39, 12, 0xffd5ead9, Paint.Align.RIGHT);
    }

    void drawScene(Canvas c) {
        if (pathCount > 1) {
            trailPath.reset(); trailPath.moveTo(pathX[0], pathY[0]);
            int end = Math.min(pathIndex + 1, pathCount);
            for (int i=1;i<end;i++) trailPath.lineTo(pathX[i], pathY[i]);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(0xffffe66d);
            c.drawPath(trailPath,p);
        }
        if (screen == 3) drawKeeper(c, keeperX, keeperY, keeperDiving);
        else drawKeeper(c, goalX()+goalW()/2f, goalY()+goalH()*.82f, false);
        if (startX > 0) drawPlayer(c,startX,startY,shooting);
        if (shooting || ballX > 0) {
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); c.drawCircle(ballX,ballY,10,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xff555555); c.drawCircle(ballX,ballY,10,p);
        }
    }

    String modeName() {
        return screen==1?"🎯 NORMAL":screen==2?"🏆 RETOS":screen==3?"🧤 MODO PORTERO":screen==4?"⚽ TIRO LIBRE":"🥅 PENAL";
    }

    void drawControls(Canvas c) {
        float base = H - 232f;
        if (screen == 3) {
            text(c,"Arrastra al portero • toca el arco para lanzarte",W/2f,base,13,Color.WHITE,Paint.Align.CENTER);
            buttonSmall(c,"Fácil",W*.20f,base+34,difficulty==0);
            buttonSmall(c,"Medio",W*.50f,base+34,difficulty==1);
            buttonSmall(c,"Difícil",W*.80f,base+34,difficulty==2);
            buttonSmall(c,"🔙 Menú",W*.22f,base+84,false);
            buttonSmall(c,"🤖 NUEVO TIRO",W*.78f,base+84,true);
            text(c,"Atajadas: "+saves+"  •  Goles: "+goals, W/2f, base+122, 12, 0xffd5ead9, Paint.Align.CENTER);
            return;
        }
        text(c,"Potencia",W*.17f,base,12,Color.WHITE,Paint.Align.CENTER);
        text(c,"Curva",W*.50f,base,12,Color.WHITE,Paint.Align.CENTER);
        text(c,"Altura",W*.83f,base,12,Color.WHITE,Paint.Align.CENTER);
        slider(c,W*.07f,W*.28f,base+25,power,1,100);
        slider(c,W*.39f,W*.61f,base+25,curve,-40,40);
        slider(c,W*.71f,W*.93f,base+25,height,10,90);
        buttonSmall(c,"🔙 Menú",W*.19f,base+76,false);
        buttonSmall(c,screen==2?"🎯 RETO":"⚽ DISPARAR",W*.50f,base+76,true);
        buttonSmall(c,"↻",W*.81f,base+76,false);
        text(c,"Dificultad",W/2f,base+112,12,Color.WHITE,Paint.Align.CENTER);
        buttonSmall(c,"Fácil",W*.25f,base+141,difficulty==0);
        buttonSmall(c,"Medio",W*.50f,base+141,difficulty==1);
        buttonSmall(c,"Difícil",W*.75f,base+141,difficulty==2);
    }

    void slider(Canvas c,float l,float r,float y,float val,float min,float max) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(0x88ffffff); c.drawLine(l,y,r,y,p);
        float q=(val-min)/(max-min); q=clamp(q,0,1);
        p.setColor(0xffffe66d); c.drawLine(l,y,l+(r-l)*q,y,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); c.drawCircle(l+(r-l)*q,y,10,p); p.setStrokeCap(Paint.Cap.BUTT);
    }

    void button(Canvas c,String s,float cy,int color) {
        float l=W*.12f,r=W*.88f; round(c,l,cy-25,r,cy+25,16,color); text(c,s,W/2f,cy+7,17,Color.WHITE,Paint.Align.CENTER);
    }
    void buttonSmall(Canvas c,String s,float cx,float cy,boolean on) {
        round(c,cx-62,cy-21,cx+62,cy+21,13,on?0xffa56f14:0x66303030); text(c,s,cx,cy+6,12,Color.WHITE,Paint.Align.CENTER);
    }

    void drawPlayer(Canvas c,float x,float y,boolean moving) {
        float step=moving?(float)Math.sin(playerAnim*13f)*7f:0;
        if(playerBmp!=null){c.drawBitmap(playerBmp,null,new RectF(x-28+step,y-58,x+28+step,y),p);return;}
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); c.drawCircle(x,y-38,10,p); c.drawRoundRect(x-10,y-29,x+10,y+5,5,5,p);
        p.setStrokeWidth(5); c.drawLine(x-5,y+4,x-12+step,y+28,p); c.drawLine(x+5,y+4,x+12-step,y+28,p);
    }

    void drawKeeper(Canvas c,float x,float y,boolean dive) {
        if(x<=0)return;
        float d=dive?easeOut(clamp(keeperAnim,0,1)):0;
        float xx=x+(keeperGoalX-x)*d, yy=y+(keeperGoalY-y)*d;
        if(keeperBmp!=null){c.drawBitmap(keeperBmp,null,new RectF(xx-32,yy-70,xx+32,yy+5),p);return;}
        p.setStyle(Paint.Style.FILL); p.setColor(0xffffd35a); c.drawCircle(xx,yy-48,10,p); p.setColor(0xff2d65c8); c.drawRoundRect(xx-12,yy-38,xx+12,yy-4,6,6,p);
        p.setStrokeWidth(5); c.drawLine(xx-8,yy-5,xx-17,yy+22,p); c.drawLine(xx+8,yy-5,xx+17,yy+22,p);
    }

    void chooseDefault() {
        targetX=goalX()+goalW()*.65f; targetY=goalY()+goalH()*.50f;
        keeperX=goalX()+goalW()*.5f; keeperY=goalY()+goalH()*.82f;
        startX=W*.18f; startY=H*.63f; ballX=startX; ballY=startY;
    }

    void ensureDefault(){ if(targetX<=0) chooseDefault(); }

    void shoot() {
        if(shooting)return;
        ensureDefault();
        attempts++;
        if(screen==2){challenge++; targetX=goalX()+goalW()*(.10f+rng.nextFloat()*.80f); targetY=goalY()+goalH()*(.08f+rng.nextFloat()*.84f);}
        startX=W*.18f; startY=H*.63f;
        beginShot(false);
    }

    void botShotKeeper() {
        if(shooting)return;
        attempts++;
        startX=W*(.16f+rng.nextFloat()*.25f); startY=H*(.47f+rng.nextFloat()*.18f);
        targetX=goalX()+goalW()*(.08f+rng.nextFloat()*.84f); targetY=goalY()+goalH()*(.08f+rng.nextFloat()*.84f);
        if(difficulty==0){curve=0;height=40;power=50;}
        else if(difficulty==1){curve=-18+rng.nextFloat()*36;height=35+rng.nextFloat()*35;power=65+rng.nextFloat()*20;}
        else{curve=-40+rng.nextFloat()*80;height=20+rng.nextFloat()*65;power=80+rng.nextFloat()*20;}
        beginShot(true);
    }

    void beginShot(boolean bot) {
        shooting=true; shotResolved=false; shotTime=0f; playerAnim=0f; keeperAnim=0f; keeperDiving=false;
        ballX=startX; ballY=startY; pathCount=0; pathIndex=0; trailPath.reset();
        keeperX=goalX()+goalW()*.5f; keeperY=goalY()+goalH()*.82f; keeperGoalX=keeperX; keeperGoalY=keeperY;
        shotDuration = clamp(1.18f - power*.0060f, .56f, 1.18f);
        buildTrajectory();
        lastFrameNs=System.nanoTime();
        postInvalidateOnAnimation();
    }

    void buildTrajectory() {
        int n=100; pathCount=n+1;
        float sx=startX, sy=startY, ex=targetX, ey=targetY;
        for(int i=0;i<=n;i++){
            float t=i/(float)n;
            float x=sx+(ex-sx)*t;
            float lift=(float)Math.sin(Math.PI*t)*(height/100f)*150f;
            float side=(float)Math.sin(Math.PI*t)*curve*2.15f;
            pathX[i]=x+side; pathY[i]=sy+(ey-sy)*t-lift;
        }
    }

    void updateFrame() {
        long now=System.nanoTime();
        float dt=(now-lastFrameNs)/1_000_000_000f;
        lastFrameNs=now;
        if(dt<0f||dt>.10f)dt=.016f;
        shotTime+=dt; playerAnim+=dt;
        float t=clamp(shotTime/shotDuration,0f,1f);
        int idx=Math.min(pathCount-1,(int)(t*(pathCount-1)));
        pathIndex=idx; ballX=pathX[idx]; ballY=pathY[idx];
        if(screen==3 && keeperDiving) keeperAnim=clamp(shotTime/.42f,0f,1f);
        if(t>=1f){ shooting=false; resolveShot(); }
    }

    void resolveShot() {
        if(shotResolved)return; shotResolved=true;
        if(screen==3){ resolveKeeper(); return; }
        float chance=.18f+difficulty*.10f;
        if(screen==4)chance=.20f; if(screen==5)chance=.16f;
        boolean save=rng.nextFloat()<chance && height<82f;
        if(save){saves++;streak=0;toast="🧤 ¡ATAJADA!";}
        else{goals++;streak++;record=Math.max(record,streak);toast="⚽ ¡GOL!";}
        toastUntil=System.currentTimeMillis()+1000L;
        invalidate();
    }

    void resolveKeeper(){
        float d=easeOut(clamp(keeperAnim,0f,1f));
        float px=keeperX+(keeperGoalX-keeperX)*d, py=keeperY+(keeperGoalY-keeperY)*d;
        float dist=(float)Math.hypot(targetX-px,targetY-py);
        boolean caught=dist < 50f+(difficulty==0?12f:0f);
        if(caught){saves++;streak++;record=Math.max(record,streak);toast="🧤 ¡ATAJADA!";}
        else{goals++;streak=0;toast="⚽ ¡GOL!";}
        toastUntil=System.currentTimeMillis()+1000L;
        invalidate();
    }

    void setKeeperTarget(float x,float y){keeperGoalX=x;keeperGoalY=y;keeperDiving=true;keeperAnim=0f;}

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY(); int a=e.getActionMasked();
        if(a==MotionEvent.ACTION_DOWN){
            if(screen==0){
                float top=Math.max(145f,H*.22f), bottom=Math.min(H-90f,top+310f), gap=(bottom-top)/4f;
                for(int i=0;i<5;i++) if(y>top+i*gap-30&&y<top+i*gap+30){screen=i+1;reset();invalidate();return true;}
                return true;
            }
            if(screen==3){
                if(!shooting && Math.hypot(x-keeperX,y-keeperY)<70){draggingKeeper=true;return true;}
                if(!shooting && x>goalX()-35&&x<goalX()+goalW()+35&&y>goalY()-25&&y<goalY()+goalH()+25){setKeeperTarget(x,y);botShotKeeper();return true;}
            }
        }
        if(screen==3 && a==MotionEvent.ACTION_MOVE && draggingKeeper && !shooting){
            keeperX=clamp(x,goalX(),goalX()+goalW()); keeperY=clamp(y,goalY()+goalH()*.48f,goalY()+goalH()); invalidate(); return true;
        }
        if(screen==3 && a==MotionEvent.ACTION_UP){
            draggingKeeper=false; float base=H-232f;
            if(y>base+55 && y<base+112){
                if(x<W*.38f){screen=0;reset();invalidate();return true;}
                if(x>W*.62f){botShotKeeper();return true;}
            }
            if(y>base+10 && y<base+58){difficulty=x<W*.38f?0:(x<W*.62f?1:2);invalidate();return true;}
            return true;
        }
        if(a==MotionEvent.ACTION_UP){
            float base=H-232f;
            if(y>base+48 && y<base+108){
                if(x<W*.34f){screen=0;reset();invalidate();return true;}
                if(x>W*.34f&&x<W*.66f){if(screen==1||screen==2||screen==4||screen==5)shoot();return true;}
                reset();invalidate();return true;
            }
            if(y>base+112){difficulty=x<W*.38f?0:(x<W*.62f?1:2);invalidate();return true;}
            if(y>base-8 && y<base+48){
                float l=W*.07f,r=W*.28f;if(x>=l&&x<=r)power=clamp((x-l)/(r-l)*99f+1f,1,100);
                l=W*.39f;r=W*.61f;if(x>=l&&x<=r)curve=clamp((x-l)/(r-l)*80f-40f,-40,40);
                l=W*.71f;r=W*.93f;if(x>=l&&x<=r)height=clamp((x-l)/(r-l)*80f+10f,10,90);
                invalidate();return true;
            }
            if(x>goalX()&&x<goalX()+goalW()&&y>goalY()&&y<goalY()+goalH()&&!shooting){targetX=x;targetY=y;invalidate();return true;}
        }
        return true;
    }

    float goalX(){return W*.74f;} float goalY(){return H*.20f;} float goalW(){return W*.23f;} float goalH(){return H*.56f;}
    float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    float easeOut(float x){float q=1f-x;return 1f-q*q;}
    void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){p.setTextSize(size);p.setColor(color);p.setTextAlign(align);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
}
