plugins { id("com.android.application") }

android {
    namespace = "com.trayectoriadetiros"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.trayectoriadetiros"
        minSdk = 23
        targetSdk = 35
        versionCode = 23
        versionName = "2.3"
    }
}
